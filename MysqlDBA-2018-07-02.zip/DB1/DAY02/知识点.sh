#约束条件
#	语法结构  ALTER TABLE 表名 执行动作 ;
#	添加新字段ALTER TABLE 表名
#		ADD 字段名 类型 ( 宽度 ) 约束条件 ;
#		可加 AFTER 字段名 ;
#		或者 FIRST;
#	修改字段类型
#		ALTER TABLE 表名 modify 字段名 类型 ( 宽度 ) 约束条件 ;
#		可加 after 字段名 ;或者 first;
#	修改字段名
# 		alter table 表名 change 源字段名  新字段名  类型（宽度）  约束条件；
#	删除字段
#	修改表名
#修改表结构
#
#MySQL 键值
